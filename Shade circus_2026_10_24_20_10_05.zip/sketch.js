function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //head
  fill(209,165,114);
  ellipse(200,200,350,400)
  //nose
  triangle(200,100,150,200,250,200);
  //mouth and chin
  fill(209,114,114);
  ellipse (200,250,100,25);
  line (150,250,250,250);
  fill(209,165,114);
  ellipse (200,325,100,50);
  //Glasses
  line(80,125,40,125);
  rect (80,100,100,50);
  line(360,125,320,125);
  rect (220,100,100,50);
  line(180,125,220,125);
  //left eye
  fill(255,255,255);
  ellipse(130,125,55,40);
  fill(51,25,0);
  circle(130,125,40);
  fill(0,0,0);
  circle(130,125,10);
  point(130,125);
  //right eye
  fill(255,255,255);
  ellipse(270,125,55,40);
  fill(51,25,0);
  circle(270,125,40);
  fill(0,0,0);
  circle(270,125,10);
  point(270,125);
  text('Self Portrait', 10,10);
  text('Kraig Mougeot',10,395);
}